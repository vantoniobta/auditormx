 
$(document).ready(function() {

	
	$('#hide-menu >:first-child > a').click(function(e) {
		$('body').toggleClass("hidden-menu");
		$('#page-content').toggleClass("mobile-content");
			e.preventDefault();
	});
	
	
//	function layoutSidebar(){
//	
//		var width = $(window).width();
//		
//		if (width  <=  700){
//		
//			$('body').removeClass();
//			$('body').addClass("mobile-menu");
//			
//			$('#hide-menu >:first-child > a').click(function(e) {
//				$('body').toggleClass("mobile-menu");
//				$('#page-content').toggleClass("mobile-content");
//					e.preventDefault();
//			});
//			
//		}else if (width >= 700){
//		
//			$('body').removeClass();
//				
//			$('#hide-menu >:first-child > a').click(function(e) {
//				$('body').toggleClass("hidden-menu");
//					e.preventDefault();
//			});
//		}
//	
//	}
	
	
	
	function sidebar(){
	
	   $('.hideLink').hide();
	
	    $( '#sidebar li' ).each( function(){
	
	      $( this ).children( 'a.mainLink' ).click( function () {
	      
	      	var display = $( this ).parent();
	      	var links = $(this).parent().attr('id');
	      	
	      
		      if ( $( '#sidebar li' ).has( '#' + links ) ){
		      
		      	$( '#sidebar li:not(#' + links + ')' ).children( 'ul' ).slideUp( 300 );
		      	
		      	      	
		      	$( '#sidebar li#' + links +' a.mainLink' ).children( 'b' ).children( 'i' ).toggleClass( ' fa-plus-square-o fa-minus-square-o ' );
		      	$( '#sidebar li:not(#' + links + ')' ).children('a.mainLink').children( 'b' ).children( 'i' ).removeClass(' fa-plus-square-o fa-minus-square-o ').addClass(' fa-plus-square-o ');
		      	
		      	      
		      	$( display ).children( 'ul' ).slideToggle( 300 );
		      	
		      }else if( !$( '#sidebar li' ).has( '#' + links ) ) {
		      	      	
	      	  }
	
	      });
	
	    });
	    
	} 
	
	sidebar();
	
//	layoutSidebar();
	
//	$(window).resize(layoutSidebar);
	
});
    

